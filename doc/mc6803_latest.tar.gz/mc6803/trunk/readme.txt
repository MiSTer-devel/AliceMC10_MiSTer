File descriptions:
	6801_core.sv: CPU core file translated from VHDL.
	MC6803.sv: Old implementation of IO ports and timer of the MC6803 chip. This file will no longer be updated.
	MC6803_gen2: New implementation of IO ports and timer with bug fixes.